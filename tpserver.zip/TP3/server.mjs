"use strict";

import { createServer } from "http";
import { promises as fsPromises } from "fs";
import { fileURLToPath } from "url";
import { dirname, resolve, normalize } from "path";
import querystring from "querystring";

let Bodycount = '';

// Convert import.meta.url to a file path
const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

// processing requests
async function webserver(request, response) {
    const url = new URL(request.url, `http://${request.headers.host}`);

    if (url.pathname === "/") {
        response.setHeader("Content-Type", "text/html; charset=utf-8");
        response.end("<!doctype html><html><body>Server is working</body></html>");
    } else if (url.pathname.startsWith("/www")) {
        // Serve files from server directory and subdirectories
        const filePath = normalize(resolve(__dirname, "." + url.pathname.replace("/www", "")));
        try {
            const stats = await fsPromises.stat(filePath);
            if (!stats.isFile()) {
                throw new Error("Not a file");
            }
            const fileContent = await fsPromises.readFile(filePath);
            const contentType = getContentType(filePath);
            response.setHeader("Content-Type", contentType);
            response.end(fileContent);
        } catch (error) {
            console.error(error);
            response.writeHead(404, { "Content-Type": "text/plain" });
            response.end("File not found");
        }
    } else if (url.pathname === "/kill") {
        response.writeHead(200, { "Content-Type": "text/html; charset=utf-8" });
        response.end("The server will stop now.");
        server.close(() => {
            console.log("Server stopped.");
            process.exit(0);
        });
    } else if (url.pathname === "/hallo" && request.method === 'GET') {
        const nameParam = `${url.searchParams.get('nom')}`;
        const decodedName = decodeURIComponent(nameParam);
        response.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
        response.end(`<html><body><p>hallo ${decodedName}</p></body></html>`);
    } else if (url.pathname === "/coucou" && request.method === 'GET') {
        const nameParam = `${url.searchParams.get('name')}`;
        const decodedName = decodeURIComponent(nameParam);
        const sanitizedName = decodedName.replace(/<\/?[^>]+(>|$)/g, '');

        response.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
        response.end(`<html><body><p>coucou ${sanitizedName}, the following users have already visited this page: ${Bodycount}</p></body></html>`);
        if (Bodycount.length !== 0) {
            Bodycount += ', '
        }
        Bodycount += sanitizedName;
    } else if (url.pathname === "/clear" && request.method === 'GET') {
        Bodycount = '';
        response.end("<!doctype html><html><body>Cleared the memory</body></html>");
    } else {
        response.writeHead(403, { "Content-Type": "text/plain" });
        response.end("Forbidden");
    }
}

function getContentType(filePath) {
    const ext = filePath.split(".").pop().toLowerCase();
    switch (ext) {
        case "html":
            return "text/html";
        case "js":
            return "application/javascript";
        case "css":
            return "text/css";
        case "mjs":
            return "application/javascript";
        case "png":
            return "image/png";
        case "jpg":
        case "jpeg":
            return "image/jpeg";
        default:
            return "application/octet-stream";
    }
}

const port = process.argv[2] || 8000;

const server = createServer(webserver);

server.listen(port, () => {
    console.log(`Server is listening on port ${port}`);
});
