import http from 'http';
import express from 'express';
import fs from 'fs';
import morgan from 'morgan';
import { promises as fsPromises } from 'fs';

const port = process.argv[2] || 8000;
const logFormat = ':method :url :status :res[content-length] - :response-time ms';

const app = express();
const server = http.createServer(app);

app.use(morgan(logFormat));

app.get('/', (req, res) => {
  res.writeHead(200, { 'Content-Type': 'text/plain; charset=utf-8' });
  res.end('Hi');
});

app.get('/end', (req, res) => {
  res.writeHead(200, { 'Content-Type': 'text/plain; charset=utf-8' });
  res.end('Server will stop now.');
  server.close(() => {
    console.log('Server stopped.');
    process.exit(0);
  });
});

app.get('/clean', (req, res) => {
  reloadDb()
    .then(() => {
      res.writeHead(200, { 'Content-Type': 'text/plain; charset=utf-8' });
      res.end('db.json reloaded');
    })
    .catch((error) => {
      console.error('Error during reload:', error.message);
      res.writeHead(500, { 'Content-Type': 'text/plain; charset=utf-8' });
      res.end('Internal Server Error');
    });
});

app.get('/countpapers', (req, res) => {
  fs.readFile('db.json', 'utf-8', (err, data) => {
    if (err) {
      res.writeHead(500, { 'Content-Type': 'text/plain' });
      res.end('Internal Server Error');
      return;
    }
    const publications = JSON.parse(data);
    const count = publications.length;
    res.writeHead(200, { 'Content-Type': 'text/plain' });
    res.end(`${count}`);
  });
});

app.get('/auth/:authorName', (req, res) => {
  const authorName = req.params.authorName.toLowerCase();
  fs.readFile('db.json', 'utf-8', (err, data) => {
    if (err) {
      res.writeHead(500, { 'Content-Type': 'text/plain' });
      res.end('Internal Server Error');
      return;
    }
    const publications = JSON.parse(data);
    const count = publications.filter(pub => pub.authors.some(author => author.toLowerCase().includes(authorName))).length;
    res.writeHead(200, { 'Content-Type': 'text/plain' });
    res.end(`${count}`);
  });
});

app.get('/papersfrom/:authorName', (req, res) => {
  const authorName = req.params.authorName.toLowerCase();
  fs.readFile('db.json', 'utf-8', (err, data) => {
    if (err) {
      res.writeHead(500, { 'Content-Type': 'text/plain' });
      res.end('Internal Server Error');
      return;
    }
    const publications = JSON.parse(data);
    const matchingPublications = publications.filter(pub => pub.authors.some(author => author.toLowerCase().includes(authorName)));
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify(matchingPublications));
  });
});

app.get('/ttlist/:authorName', (req, res) => {
  const authorName = req.params.authorName.toLowerCase();
  fs.readFile('db.json', 'utf-8', (err, data) => {
    if (err) {
      res.writeHead(500, { 'Content-Type': 'text/plain' });
      res.end('Internal Server Error');
      return;
    }
    const publications = JSON.parse(data);
    const titles = publications.filter(pub => pub.authors.some(author => author.toLowerCase().includes(authorName))).map(pub => pub.title);
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify(titles));
  });
});

app.get('/reference/:key', (req, res) => {
  const key = req.params.key;
  fs.readFile('db.json', 'utf-8', (err, data) => {
    if (err) {
      res.writeHead(500, { 'Content-Type': 'text/plain' });
      res.end('Internal Server Error');
      return;
    }
    const publications = JSON.parse(data);
    const matchingPublication = publications.find(pub => pub.key === key);
    if (matchingPublication) {
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify(matchingPublication));
    } else {
      res.writeHead(404, { 'Content-Type': 'text/plain' });
      res.end('Publication not found');
    }
  });
});

app.delete('/reference/:key', (req, res) => {
  const key = req.params.key;
  fs.readFile('db.json', 'utf-8', (err, data) => {
    if (err) {
      res.writeHead(500, { 'Content-Type': 'text/plain' });
      res.end('Internal Server Error');
      return;
    }
    let publications = JSON.parse(data);
    const indexToRemove = publications.findIndex(pub => pub.key === key);
    if (indexToRemove !== -1) {
      publications.splice(indexToRemove, 1);
      fs.writeFile('db.json', JSON.stringify(publications, null, 2), (writeErr) => {
        if (writeErr) {
          res.writeHead(500, { 'Content-Type': 'text/plain' });
          res.end('Internal Server Error');
          return;
        }
        res.writeHead(200, { 'Content-Type': 'text/plain' });
        res.end(`Publication with key '${key}' deleted`);
      });
    } else {
      res.writeHead(404, { 'Content-Type': 'text/plain' });
      res.end(`Publication with key '${key}' not found`);
    }
  });
});

app.post('/reference', (req, res) => {
  const imaginaryPublication = {"key":"imaginary","title":"fun","journal":"pifpoche","year":"1960","authors":["dufourd"]};
  fs.readFile('db.json', 'utf-8', (err, data) => {
    if (err) {
      res.writeHead(500, { 'Content-Type': 'text/plain' });
      res.end('Internal Server Error');
      return;
    }
    const publications = JSON.parse(data);
    publications.push(imaginaryPublication);
    fs.writeFile('db.json', JSON.stringify(publications, null, 2), (writeErr) => {
      if (writeErr) {
        res.writeHead(500, { 'Content-Type': 'text/plain' });
        res.end('Internal Server Error');
        return;
      }
      res.writeHead(200, { 'Content-Type': 'text/plain' });
      res.end('Imaginary publication added successfully');
    });
  });
});

app.put('/reference/:key', (req, res) => {
  const key = req.params.key;
  const newPublication = {"key":"imaginary","title":"morefun","journal":"tintin","year":"1960","authors":["dufourd"]};
  fs.readFile('db.json', 'utf-8', (err, data) => {
    if (err) {
      res.writeHead(500, { 'Content-Type': 'text/plain' });
      res.end('Internal Server Error');
      return;
    }
    let publications = JSON.parse(data);
    const indexToUpdate = publications.findIndex(pub => pub.key === key);
    if (indexToUpdate !== -1) {
      publications[indexToUpdate] = newPublication;
      fs.writeFile('db.json', JSON.stringify(publications, null, 2), (writeErr) => {
        if (writeErr) {
          res.writeHead(500, { 'Content-Type': 'text/plain' });
          res.end('Internal Server Error');
          return;
        }
        res.writeHead(200, { 'Content-Type': 'text/plain' });
        res.end(`Publication with key '${key}' updated`);
      });
    } else {
      res.writeHead(404, { 'Content-Type': 'text/plain' });
      res.end(`Publication with key '${key}' not found`);
    }
  });
});

app.get('/kill', (req, res) => {
  res.writeHead(200, { 'Content-Type': 'text/plain; charset=utf-8' });
  res.end('Server will stop now.');
  server.close(() => {
    console.log('Server stopped.');
    process.exit(0);
  });
});

server.listen(port, () => {
  console.log(`Server is listening on port ${port}`);
});

async function reloadDb() {
  const dbContent = await fsPromises.readFile('db.json', 'utf-8');
}
