export function wordCount (texte) {
    const result = {};
    let mots = texte.split(" ");
    for (let mot of mots) {
        if (mot in result) {
            result[mot] += 1;
        } else {
            result[mot] = 1;
        }
    }
    return result;
}

export class WordL {
    constructor(text) {
      this.words = text.split(/\s+/);
      this.words.sort();
    }
  
    getWords() {
      return [...new Set(this.words)];
    }
  
    maxCountWord() {
      let maxWord = this.words[0];
      let maxCount = 0;
  
      for (const word of this.words) {
        const count = this.getCount(word);
  
        if (count > maxCount) {
          maxCount = count;
          maxWord = word;
        }
      }
  
      return maxWord;
    }
  
    minCountWord() {
      let minWord = this.words[0];
      let minCount = this.getCount(minWord);
  
      for (const word of this.words) {
        const count = this.getCount(word);
  
        if (count < minCount) {
          minCount = count;
          minWord = word;
        }
      }
  
      return minWord;
    }
  
    getCount(word) {
      return this.words.filter(w => w === word).length;
    }

    applyWordFunc(f) {
        const resultf = [];
        for (const word of [...new Set(this.words)]) {
            resultf.push(f(word));
        }          
        return resultf;
  }
}
