"use strict";

import {fibo_it,fibRec,fibArr,fibonaMap} from "./exercise1.mjs";

console.log(fibo_it(0));
console.log(fibo_it(1));
console.log(fibo_it(2));
console.log(fibo_it(9));

console.log(fibRec(0));
console.log(fibRec(1));
console.log(fibRec(2));
console.log(fibRec(9));

console.log(fibArr([3,5]));
console.log(fibonaMap([3,5]));
