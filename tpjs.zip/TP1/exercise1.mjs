"use strict";

// iterative
export function fiboIt(n) {
    if (n == 0) {
        return 0;
    }

    let fib = 1;
    let fib_prec = 0;

    for (let k = 1; k < n; k++) {
        let temp = fib;
        fib = fib + fib_prec;
        fib_prec = temp;
    }

    return fib;
}

// recursive function
export function fibo_rec(n) {
    if (n==0) {
        return 0
    }

    if (n==1) {
        return 1
    }

    return fibo_rec(n-1)+fibo_rec(n-2)
}

// no map function
export function fibArr(t) {
    let fibArr = [];
    for (let k = 0; k < t.length; k++) {
        fibArr.push(fibo_rec(t[k]));
    }

    return fibArr;
}

// using map
export function fibo_map(t) {
    return t.map(fibo_rec)
}