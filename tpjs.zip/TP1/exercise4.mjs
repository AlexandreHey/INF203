import {Student, FrStd} from "./exercise3.mjs";
import * as fs from 'fs';

export class Prom {
    constructor() {
      this.students = [];
    }
  
    add(student) {
      this.students.push(student);
    }
  
    size() {
      return this.students.length;
    }
  
    get(i) {
      return this.students[i];
    }
  
    print() {
      this.students.forEach(student => console.log(student.toString()));
    }
  
    write() {
      return JSON.stringify(this.students);
    }
  
    read(str) {
      const parsedData = JSON.parse(str);
      this.students = parsedData.map(studentData => {
          if (studentData.nationality) {
              return new FrStd(studentData.lastName, studentData.firstName, studentData.id, studentData.nationality);
          } else {
              return new Student(studentData.lastName, studentData.firstName, studentData.id);
          }
      });
  }
  
    saveFile(fileName) {
        const dataToWrite = this.write();
        fs.writeFileSync(fileName, dataToWrite, 'utf8');
      }
  
      readFile(fileName) {
        const dataRead = fs.readFileSync(fileName, 'utf8');
        this.read(dataRead);
      }
  }