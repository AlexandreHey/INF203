import {Student, FrStdt} from "./exercise3.mjs";
import {Prom} from "./exercise4.mjs";
import * as fs from 'fs';

const promotion = new Prom();

const student1 = new Student("Dupond", "Jean", 1835);
const student2 = new FrStdt("Doe", "John", 432, "American");

promotion.add(student1);
promotion.add(student2);

console.log(promotion.size());
promotion.print();

const serializedPromotion = promotion.write();
console.log(serializedPromotion);

// Save to file
promotion.saveFile('promotion.json');

// Read from file
const newPromotion = new Prom();
newPromotion.readFromFile('promotion.json');
newPromotion.print();