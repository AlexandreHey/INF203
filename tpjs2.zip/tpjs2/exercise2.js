function sendMessage() {
    var message = document.getElementById("textedit").value;

    if (message.trim() !== "") {
        var xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                document.getElementById("textedit").value = ""; 
                loadChat();
            }
        };
        xhttp.open("GET", "chat.php?phrase=" + encodeURIComponent(message), true);
        xhttp.send();
    }
}

function loadChat() {
    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            var chatLines = this.responseText.split('\n');
            var chatDiv = document.getElementById("tarea");
            chatDiv.innerHTML = "";

            for (var i = chatLines.length - 1; i >= 0; i--) {
                if (chatLines[i].trim() !== "") {
                    var pElement = document.createElement("p");
                    pElement.textContent = chatLines[i].trim();
                    chatDiv.appendChild(pElement);

                    if (chatDiv.childElementCount >= 10) {
                        break;
                    }
                }
            }
        }
    };
    xhttp.open("GET", "chatlog.txt", true);
    xhttp.send();
}

loadChat();
setInterval(loadChat, 1000);