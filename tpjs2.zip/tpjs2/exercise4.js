var slides = [];
var currentIndex = -1;
var slideshowInterval;
var isSlideshowPlaying = false;

function loadJSON(callback) {   
    var xobj = new XMLHttpRequest();
    xobj.overrideMimeType("application/json");
    xobj.open('GET', 'slides.json', true); 
    xobj.onreadystatechange = function () {
          if (xobj.readyState == 4 && xobj.status == "200") {
            callback(JSON.parse(xobj.responseText));
          }
    };
    xobj.send(null);  
}

function displaySlide(index) {
    let slshDiv = document.getElementById("container");
    slshDiv.innerHTML = '';

    if (index >= 0 && index < slides.length) {
        let slide = slides[index];
        let iframe = document.createElement('iframe');
        iframe.src = slide.url || 'about:blank'; 
        slshDiv.appendChild(iframe);
    }
}

function playSlideshow() {
    if (!isSlideshowPlaying) {
        isSlideshowPlaying = true;
        advanceSlideshow();
    }
}

function advanceSlideshow() {
    currentIndex = (currentIndex + 1) % slides.length;
    displaySlide(currentIndex);
    slideshowInterval = setTimeout(advanceSlideshow, 2000); 
}

function pauseContinueSlideshow() {
    if (isSlideshowPlaying) {
        clearTimeout(slideshowInterval);
        isSlideshowPlaying = false;
    } else {
        isSlideshowPlaying = true;
        advanceSlideshow();
    }
}

function nextSlide() {
    clearTimeout(slideshowInterval);
    currentIndex = (currentIndex + 1) % slides.length;
    displaySlide(currentIndex);
    
    if (isSlideshowPlaying) {
        advanceSlideshow(); 
    }
}

function previousSlide() {
    clearTimeout(slideshowInterval);
    currentIndex = (currentIndex - 1 + slides.length) % slides.length;
    displaySlide(currentIndex);
    isSlideshowPlaying = false; 
}

window.onload = function() {
    loadJSON(function(json) {
        slides = json.slides;
    });
};
