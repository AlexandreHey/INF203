var slides = [];
var currentIndex = 0;
var slideshowInterval;

function loadJSON(callback) {   
    var xobj = new XMLHttpRequest();
    xobj.overrideMimeType("application/json");
    xobj.open('GET', 'slides.json', true); 
    xobj.onreadystatechange = function () {
          if (xobj.readyState == 4 && xobj.status == "200") {
            callback(JSON.parse(xobj.responseText));
          }
    };
    xobj.send(null);  
}

function displaySlide(index) {
    if (index >= 0 && index < slides.length) {
        let slide = slides[index];
        let slshDiv = document.getElementById("container");
        slshDiv.innerHTML = '';

        if (slide.url) {
            let iframe = document.createElement('iframe');
            iframe.src = slide.url;
            slshDiv.appendChild(iframe);
        }
    }
}

function playSlideshow() {
    loadJSON(function(json) {
        slides = json.slides;
        currentIndex = 0;
        displaySlide(currentIndex); 

        slideshowInterval = setInterval(function() {
            currentIndex++;
            if (currentIndex < slides.length) {
                displaySlide(currentIndex);
            } else {
                clearInterval(slideshowInterval);
                document.getElementById("container").innerHTML = ''; 
            }
        }, 2000); 
    });
}

function nextSlide() {
    clearInterval(slideshowInterval);
    currentIndex++;
    if (currentIndex >= slides.length) {
        currentIndex = 0;
    }
    displaySlide(currentIndex);
}

function previousSlide() {
    clearInterval(slideshowInterval);
    currentIndex--;
    if (currentIndex < 0) {
        currentIndex = slides.length - 1;
    }
    displaySlide(currentIndex);
}
