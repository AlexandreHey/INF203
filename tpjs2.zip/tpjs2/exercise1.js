function loadDoc() {
    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            document.getElementById("tarea").value = this.responseText;
        }
    };
    xhttp.open("GET", "text.txt", true);
    xhttp.send();
}


function loadDoc2() {
    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            var textArray = this.responseText.split('\n');
            var coloredText = '';

            for (var i = 0; i < textArray.length; i++) {
                var color = getRandomColor();
                coloredText += '<p style="color:' + color + ';">' + textArray[i] + '</p>';
            }

            document.getElementById("tarea2").innerHTML = coloredText;
        }
    };
    xhttp.open("GET", "text.txt", true);
    xhttp.send();
}

function getRandomColor() {
    var letters = '0123456789ABCDEF';
    var color = '#';
    for (var i = 0; i < 6; i++) {
        color += letters[Math.floor(Math.random() * 16)];
    }
    return color;
}